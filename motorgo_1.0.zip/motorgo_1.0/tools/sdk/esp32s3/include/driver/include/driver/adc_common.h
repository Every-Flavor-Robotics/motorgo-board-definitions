/*
 * SPDX-FileCopyrightText: 2021 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * This file is only a wrapper for `driver/adc.h` for back-compatability.
 */

#include "adc.h"
